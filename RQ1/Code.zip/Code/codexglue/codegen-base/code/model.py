# Copyright (c) Microsoft Corporation. 
# Licensed under the MIT license.
import torch
import torch.nn as nn
import torch
from torch.autograd import Variable
import copy
import torch.nn.functional as F
from torch.nn import CrossEntropyLoss, MSELoss
import numpy as np

class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        #self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, features, **kwargs):
        #x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        #print("features=======", np.shape(x), x) # 
        x = features
        #x = self.dropout(x)
        x = self.out_proj(x)
        return x
        
class Model(nn.Module):   
    def __init__(self, encoder,config,tokenizer,args):
        super(Model, self).__init__()
        self.encoder = encoder
        self.config=config
        self.tokenizer=tokenizer
        self.classifier=RobertaClassificationHead(config)
        self.args=args
    
        
    def forward(self, input_ids=None,labels=None): 
        attention_mask = input_ids.ne(1) # 32,100
        encoder_outputs = self.encoder(input_ids= input_ids,attention_mask=input_ids.ne(1))[0]
        print('32,100,768?????????', np.shape(encoder_outputs),encoder_outputs) # 32,100,768
        
        token_embeddings = encoder_outputs
        token_embeddings = token_embeddings[:,:-1,:]
        attention_mask = attention_mask[:,:-1]

        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float() 
        outputs = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

        logits=self.classifier(outputs)
        prob=torch.sigmoid(logits)
        if labels is not None:
            labels=labels.float()
            loss=torch.log(prob[:,0]+1e-10)*labels+torch.log((1-prob)[:,0]+1e-10)*(1-labels)
            loss=-loss.mean()
            return loss,prob
        else:
            return prob
      
        
 
        


