# Copyright (c) Microsoft Corporation. 
# Licensed under the MIT license.
import torch
import torch.nn as nn
import torch
from torch.autograd import Variable
import copy
import torch.nn.functional as F
from torch.nn import CrossEntropyLoss, MSELoss
import numpy as np

class RobertaClassificationHead(nn.Module):
    """Head for sentence-level classification tasks."""

    def __init__(self, config):
        super().__init__()
        #self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.out_proj = nn.Linear(config.hidden_size, 2)

    def forward(self, features, **kwargs):
        #x = features[:, 0, :]  # take <s> token (equiv. to [CLS])
        #print("features=======", np.shape(x), x) # 
        x = features
        #x = self.dropout(x)
        x = self.out_proj(x)
        return x
        
class Model(nn.Module):   
    def __init__(self, encoder,config,tokenizer,args):
        super(Model, self).__init__()
        self.encoder = encoder
        self.config=config
        self.tokenizer=tokenizer
        self.classifier=RobertaClassificationHead(config)
        self.args=args
    
        
    def forward(self, input_ids=None,labels=None): 
        attention_mask = input_ids.ne(0) # 32,100
        model_outputs = self.encoder(input_ids= input_ids, attention_mask=attention_mask, labels=input_ids, decoder_attention_mask=attention_mask, output_hidden_states=True)

        hidden_states = model_outputs['encoder_hidden_states'][-1]
        token_embeddings = hidden_states[:, 1:, :] #去除CLS标记
        attention_mask = attention_mask[:, 1:] #去除CLS标记对应的注意力                
        for row in attention_mask:# 将每一行的最后一个 True 改为 False
             last_true_index = (row == True).nonzero(as_tuple=True)[0][-1]
             row[last_true_index] = False  
             
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        outputs = torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

        logits=self.classifier(outputs)
        prob=torch.sigmoid(logits)
        if labels is not None:
            labels=labels.float()
            loss=torch.log(prob[:,0]+1e-10)*labels+torch.log((1-prob)[:,0]+1e-10)*(1-labels)
            loss=-loss.mean()
            return loss,prob
        else:
            return prob
      
        
 
        


