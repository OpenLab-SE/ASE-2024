python run.py --output_dir=./saved_models0 --model_type=roberta --tokenizer_name=./codebert-base --model_name_or_path=./codebert-base --do_train --train_data_file=../dataset/train.jsonl --eval_data_file=../dataset/valid.jsonl --test_data_file=../dataset/test.jsonl --epoch 5 --block_size 100 --train_batch_size 32 --eval_batch_size 64 --learning_rate 2e-5 --max_grad_norm 1.0 --evaluate_during_training --seed 0  2>&1 | tee train.log && python run.py --output_dir=./saved_models0 --model_type=roberta --tokenizer_name=./codebert-base --model_name_or_path=./codebert-base --do_eval --do_test --train_data_file=../dataset/train.jsonl --eval_data_file=../dataset/valid.jsonl --test_data_file=../dataset/test.jsonl --epoch 5 --block_size 100 --train_batch_size 32 --eval_batch_size 64 --learning_rate 2e-5 --max_grad_norm 1.0 --evaluate_during_training --seed 0 2>&1 | tee test.log && python ../evaluator/evaluator.py -a ../dataset/test.jsonl -p saved_models0/predictions.txt 








